# FocusForge 2.0 — Real App Foundation

FocusForge is a production-oriented study/focus application foundation built for Web/PWA and mobile packaging.

## Included now
- React + Vite frontend
- Responsive desktop/mobile UI
- Arabic RTL + English LTR
- Dark/light themes
- Local persistence and offline mode
- Functional task search + filters + completion
- Focus timer based on an absolute end timestamp, so background tab sleep does not reset the session
- XP, levels, coins, streak progression
- Reward store
- Statistics and achievements screens
- Profile editing
- Optional Supabase email/password authentication
- Supabase PostgreSQL schema with Row Level Security
- Capacitor configuration for Android/iOS packaging
- PWA manifest + service worker

## Cloud mode
1. Create a Supabase project.
2. Run `supabase-schema.sql` in the Supabase SQL editor.
3. Copy `.env.example` to `.env`.
4. Fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
5. Run `npm install` then `npm run dev`.

Without Supabase environment variables, the app deliberately stays usable in local/offline mode.

## Mobile
After installing dependencies:

```bash
npm install
npm run build
npx cap add android
npx cap sync
npx cap open android
```

For iOS, run `npx cap add ios`, `npx cap sync`, then open the generated Xcode project on macOS.

## Important production work before store release
- Add real cloud synchronization for tasks, sessions, rewards and profile state.
- Add push/local notifications through Capacitor plugins.
- Add native 192/512 PNG app icons and splash assets.
- Add automated tests and CI.
- Configure app signing, privacy policy, terms, store metadata and production Supabase settings.
