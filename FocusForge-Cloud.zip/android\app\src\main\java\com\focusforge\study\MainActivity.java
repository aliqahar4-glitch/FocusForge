package com.focusforge.study;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
