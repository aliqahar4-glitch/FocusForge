import React,{useEffect,useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {supabase} from './supabase.js';
import {AlarmClock,ArrowUpRight,Award,BarChart3,Bell,Check,ChevronRight,Coins,Flame,Globe2,GraduationCap,LayoutDashboard,ListTodo,Menu,Moon,MoreHorizontal,Play,Plus,RotateCcw,Settings,ShieldCheck,Sparkles,Sun,Target,Trophy,UserRound,X,Zap,Clock3,CalendarDays,LogOut,LockKeyhole,Mail} from 'lucide-react';
import {AreaChart,Area,BarChart,Bar,CartesianGrid,ResponsiveContainer,Tooltip,XAxis,YAxis} from 'recharts';
import './styles.css';

const STORE='focusforge-v3';
const defaultTasks=[
 {id:'t1',title:'German — Kapitel 5 vocabulary',subject:'German',priority:'high',minutes:30,done:true},
 {id:'t2',title:'Physics — electric circuits',subject:'Physics',priority:'medium',minutes:50,done:false},
 {id:'t3',title:'English — grammar exercises',subject:'English',priority:'medium',minutes:25,done:false},
 {id:'t4',title:"Review yesterday's notes",subject:'Review',priority:'low',minutes:20,done:false}
];
const rewards=[{id:1,icon:'🎨',name:'Nebula Theme',cost:500},{id:2,icon:'🎧',name:'Focus Sound Pack',cost:350},{id:3,icon:'⚡',name:'2× XP Booster',cost:800},{id:4,icon:'🎁',name:'Mystery Chest',cost:1000}];
const weekly=[{day:'Mon',focus:1.4},{day:'Tue',focus:2.2},{day:'Wed',focus:1.8},{day:'Thu',focus:2.9},{day:'Fri',focus:2.4},{day:'Sat',focus:3.3},{day:'Sun',focus:2.1}];
const achievements=[['🌱','First Step','Complete your first focus session',true],['🔥','On Fire','Keep a 7-day streak',true],['⚡','Speed Runner','Complete 10 tasks',true],['🧠','Scholar','Study for 50 hours',false],['👑','Master','Reach level 25',false],['🌌','Deep Focus','Complete a 90-minute session',false]];
const tr={ar:{dashboard:'الرئيسية',focus:'التركيز',tasks:'المهام',rewards:'المكافآت',stats:'الإحصائيات',achievements:'الإنجازات',settings:'الإعدادات',welcome:'جاهز ترفع مستواك بالدراسة؟',today:'تقدم اليوم',start:'ابدأ التركيز',minutes:'دقيقة',completed:'مكتمل',streak:'يوم متتالي',level:'المستوى',coins:'عملات',total:'إجمالي التركيز',missions:'مهام اليوم',profile:'الملف الشخصي',add:'إضافة مهمة',newTask:'مهمة جديدة',title:'اسم المهمة',subject:'المادة',save:'حفظ',cancel:'إلغاء',all:'الكل',active:'قيد التنفيذ',done:'مكتملة',search:'ابحث عن مهمة...',noTasks:'لا توجد مهام بعد',store:'متجر المكافآت',buy:'استبدال',owned:'مملوكة',language:'اللغة',theme:'المظهر',light:'فاتح',dark:'داكن',notifications:'الإشعارات',data:'البيانات',reset:'إعادة ضبط البيانات',focusSession:'جلسة تركيز',choose:'اختر مهمة',duration:'المدة',finish:'إنهاء',login:'تسجيل الدخول',signup:'إنشاء حساب',email:'البريد الإلكتروني',password:'كلمة المرور',name:'الاسم',logout:'تسجيل الخروج',local:'وضع محلي',cloud:'مزامنة سحابية',sync:'حالة المزامنة'},en:{dashboard:'Dashboard',focus:'Focus',tasks:'Tasks',rewards:'Rewards',stats:'Statistics',achievements:'Achievements',settings:'Settings',welcome:'Ready to level up your study?',today:"Today's progress",start:'Start focus',minutes:'minutes',completed:'completed',streak:'day streak',level:'Level',coins:'coins',total:'Total focus',missions:"Today's missions",profile:'Profile',add:'Add task',newTask:'New task',title:'Task title',subject:'Subject',save:'Save',cancel:'Cancel',all:'All',active:'Active',done:'Done',search:'Search tasks...',noTasks:'No tasks yet',store:'Reward store',buy:'Redeem',owned:'Owned',language:'Language',theme:'Theme',light:'Light',dark:'Dark',notifications:'Notifications',data:'Data',reset:'Reset data',focusSession:'Focus session',choose:'Choose a task',duration:'Duration',finish:'Finish',login:'Sign in',signup:'Create account',email:'Email',password:'Password',name:'Name',logout:'Sign out',local:'Local mode',cloud:'Cloud sync',sync:'Sync status'}};

function load(){try{return JSON.parse(localStorage.getItem(STORE))||{}}catch{return {}}}
function save(s){localStorage.setItem(STORE,JSON.stringify(s))}
function today(){return new Date().toISOString().slice(0,10)}
function levelFor(xp){return Math.floor(xp/500)+1}

function App(){
 const initial=load();
 const [lang,setLang]=useState(initial.lang||'ar'),[dark,setDark]=useState(initial.dark!==false),[page,setPage]=useState(initial.page||'dashboard');
 const [tasks,setTasks]=useState([]),[xp,setXp]=useState(0),[coins,setCoins]=useState(0),[streak,setStreak]=useState(0),[lastStudy,setLastStudy]=useState(null);
 const [profileName,setProfileName]=useState('Student'),[sessionUser,setSessionUser]=useState(null),[authOpen,setAuthOpen]=useState(false),[profileOpen,setProfileOpen]=useState(false),[online,setOnline]=useState(navigator.onLine);
 const [sessions,setSessions]=useState([]),[ownedRewards,setOwnedRewards]=useState([]),[unlockedAchievements,setUnlockedAchievements]=useState([]);
 const [focusOpen,setFocusOpen]=useState(false),[selectedTask,setSelectedTask]=useState(''),[duration,setDuration]=useState(25),[endAt,setEndAt]=useState(null),[seconds,setSeconds]=useState(1500),[running,setRunning]=useState(false);
 const [modal,setModal]=useState(false),[newTitle,setNewTitle]=useState(''),[newSubject,setNewSubject]=useState('General'),[query,setQuery]=useState(''),[filter,setFilter]=useState('all');
 const t=tr[lang],dir=lang==='ar'?'rtl':'ltr';

 useEffect(()=>save({lang,dark,page}),[lang,dark,page]);
 useEffect(()=>{const a=()=>setOnline(true),b=()=>setOnline(false);addEventListener('online',a);addEventListener('offline',b);return()=>{removeEventListener('online',a);removeEventListener('offline',b)}},[]);

 const clearUserData=()=>{setTasks([]);setXp(0);setCoins(0);setStreak(0);setLastStudy(null);setSessions([]);setOwnedRewards([]);setUnlockedAchievements([]);setProfileName('Student');setSelectedTask('');setRunning(false);setEndAt(null);setFocusOpen(false)};
 const hydrateUser=async(user)=>{
   if(!supabase||!user){clearUserData();return}
   clearUserData();
   const [{data:p},{data:ts},{data:ss},{data:rr},{data:aa}]=await Promise.all([
     supabase.from('profiles').select('*').eq('id',user.id).single(),
     supabase.from('tasks').select('*').eq('user_id',user.id).order('created_at',{ascending:false}),
     supabase.from('focus_sessions').select('*').eq('user_id',user.id).order('started_at',{ascending:false}),
     supabase.from('rewards').select('*').eq('user_id',user.id),
     supabase.from('achievements').select('*').eq('user_id',user.id)
   ]);
   if(p){setProfileName(p.display_name||'Student');setLang(p.language||'ar');setDark(p.theme!=='light');setXp(p.xp||0);setCoins(p.coins||0);setStreak(p.streak||0);setLastStudy(p.last_study_date||null)}
   setTasks((ts||[]).map(x=>({id:x.id,title:x.title,subject:x.subject,priority:x.priority,minutes:x.minutes,done:x.completed})));
   setSessions(ss||[]);setOwnedRewards(rr||[]);setUnlockedAchievements(aa||[]);
 };
 useEffect(()=>{
   if(!supabase)return;
   let active=true;
   supabase.auth.getSession().then(({data})=>{if(active){window.__ffUser=data.session?.user||null;setSessionUser(data.session?.user||null)}});
   const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>{if(active){window.__ffUser=s?.user||null;setSessionUser(s?.user||null)}});
   return()=>{active=false;subscription.unsubscribe()};
 },[]);
 useEffect(()=>{if(sessionUser) hydrateUser(sessionUser); else clearUserData()},[sessionUser?.id]);

 const weeklyData=useMemo(()=>{
   const days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
   const now=new Date(); const start=new Date(now); start.setDate(now.getDate()-6);
   return days.map((d,i)=>{
     const date=new Date(start);date.setDate(start.getDate()+i);
     const key=date.toISOString().slice(0,10);
     const sec=sessions.filter(s=>s.completed&&s.started_at?.slice(0,10)===key).reduce((a,s)=>a+(s.actual_seconds||s.planned_minutes*60||0),0);
     return {day:d,focus:Math.round(sec/3600*10)/10};
   });
 },[sessions]);
 const totalMinutes=useMemo(()=>Math.round(sessions.filter(s=>s.completed).reduce((a,s)=>a+(s.actual_seconds||s.planned_minutes*60||0),0)/60),[sessions]);
 useEffect(()=>{if(!running||!endAt)return;const tick=()=>{const left=Math.max(0,Math.ceil((endAt-Date.now())/1000));setSeconds(left);if(left<=0){setRunning(false);completeFocus(true)}};tick();const id=setInterval(tick,500);return()=>clearInterval(id)},[running,endAt]);

 const filtered=useMemo(()=>tasks.filter(x=>(filter==='all'||(filter==='done'?x.done:!x.done))&&(x.title+x.subject).toLowerCase().includes(query.toLowerCase())),[tasks,filter,query]);

 const toggleTask=async id=>{
   const task=tasks.find(x=>x.id===id); if(!task)return;
   const done=!task.done;
   setTasks(ts=>ts.map(x=>x.id===id?{...x,done}:x));
   if(sessionUser&&supabase){
     await supabase.from('tasks').update({completed:done,completed_at:done?new Date().toISOString():null,updated_at:new Date().toISOString()}).eq('id',id).eq('user_id',sessionUser.id);
     if(done){
       const nx=xp+30,nc=coins+15;setXp(nx);setCoins(nc);
       await supabase.from('profiles').update({xp:nx,coins:nc,updated_at:new Date().toISOString()}).eq('id',sessionUser.id);
     }
   }
 };
 const addTask=async()=>{
   if(!newTitle.trim())return;
   if(sessionUser&&supabase){
     const {data,error}=await supabase.from('tasks').insert({user_id:sessionUser.id,title:newTitle.trim(),subject:newSubject.trim()||'General',priority:'medium',minutes:25,completed:false}).select().single();
     if(error)return;
     setTasks(ts=>[{id:data.id,title:data.title,subject:data.subject,priority:data.priority,minutes:data.minutes,done:false},...ts]);
   }else{
     setTasks(ts=>[{id:crypto.randomUUID?.()||Date.now().toString(),title:newTitle.trim(),subject:newSubject.trim()||'General',priority:'medium',minutes:25,done:false},...ts]);
   }
   setNewTitle('');setNewSubject('General');setModal(false);
 };
 const startFocus=()=>{const end=Date.now()+duration*60000;setSeconds(duration*60);setEndAt(end);setRunning(true);setFocusOpen(true)};
 const completeFocus=async(auto)=>{
   setRunning(false);setEndAt(null);if(!focusOpen&&!auto)return;setFocusOpen(false);
   if(sessionUser&&supabase){
     const started=new Date(Date.now()-duration*60000).toISOString();
     const {data}=await supabase.from('focus_sessions').insert({user_id:sessionUser.id,planned_minutes:duration,actual_seconds:duration*60,completed:true,started_at:started,ended_at:new Date().toISOString()}).select().single();
     if(data)setSessions(s=>[data,...s]);
     const nx=xp+120,nc=coins+25;let ns=streak;
     const td=today();if(lastStudy!==td){ns=(streak||0)+1;setStreak(ns);setLastStudy(td)}
     setXp(nx);setCoins(nc);
     await supabase.from('profiles').update({xp:nx,coins:nc,streak:ns,last_study_date:td,updated_at:new Date().toISOString()}).eq('id',sessionUser.id);
   }else{
     setXp(v=>v+120);setCoins(v=>v+25);if(lastStudy!==today()){setStreak(v=>v+1);setLastStudy(today())}
   }
 };
 const cancelFocus=()=>{setRunning(false);setEndAt(null);setFocusOpen(false)};
 const resetTimer=()=>{setRunning(false);setEndAt(null);setSeconds(duration*60)};
 const updateProfile=async(name)=>{
   const n=name.trim()||'Student';setProfileName(n);
   if(sessionUser&&supabase)await supabase.from('profiles').update({display_name:n,updated_at:new Date().toISOString()}).eq('id',sessionUser.id);
 };
 const reset=()=>{localStorage.removeItem(STORE);clearUserData();location.reload()};

 return <div className={dark?'app dark':'app'} dir={dir}>
  <aside className="sidebar"><div className="brand"><div className="brandMark"><Zap size={21}/></div><div><b>FocusForge</b><span>Study. Focus. Level Up.</span></div></div><nav>{[['dashboard',LayoutDashboard,t.dashboard],['focus',AlarmClock,t.focus],['tasks',ListTodo,t.tasks],['rewards',Coins,t.rewards],['stats',BarChart3,t.stats],['achievements',Trophy,t.achievements]].map(([k,I,l])=><button key={k} className={page===k?'navItem active':'navItem'} onClick={()=>setPage(k)}><I size={19}/><span>{l}</span>{page===k&&<ChevronRight className="navArrow" size={16}/>}</button>)}</nav><div className="sidebarBottom"><button className="navItem" onClick={()=>setPage('settings')}><Settings size={19}/><span>{t.settings}</span></button><div className="miniProfile"><div className="avatar">{profileName[0]?.toUpperCase()}</div><div><b>{profileName}</b><span>Level {levelFor(xp)} · {xp.toLocaleString()} XP</span></div></div></div></aside>
  <main className="main"><header className="topbar"><div className="mobileBrand"><div className="brandMark"><Zap size={18}/></div><b>FocusForge</b></div><div className="topActions"><span className="syncBadge">{online?(sessionUser&&supabase?t.cloud:t.local):'Offline'}</span><button className="iconBtn" onClick={()=>setDark(v=>!v)}>{dark?<Sun size={18}/>:<Moon size={18}/>}</button><button className="langBtn" onClick={()=>setLang(v=>v==='ar'?'en':'ar')}><Globe2 size={16}/>{lang==='ar'?'EN':'عربي'}</button><button className="iconBtn"><Bell size={18}/></button><button className="avatar small avatarBtn" onClick={()=>setProfileOpen(true)}>{profileName[0]?.toUpperCase()}</button></div></header>
   {page==='dashboard'&&<Dashboard t={t} xp={xp} level={levelFor(xp)} coins={coins} streak={streak} tasks={tasks} totalMinutes={totalMinutes} onFocus={startFocus} toggleTask={toggleTask} setPage={setPage}/>} 
   {page==='focus'&&<FocusPage t={t} tasks={tasks} selectedTask={selectedTask} setSelectedTask={setSelectedTask} duration={duration} setDuration={setDuration} onStart={startFocus}/>} 
   {page==='tasks'&&<TasksPage t={t} tasks={filtered} query={query} setQuery={setQuery} filter={filter} setFilter={setFilter} toggleTask={toggleTask} openModal={()=>setModal(true)} onFocus={startFocus}/>} 
   {page==='rewards'&&<RewardsPage t={t} coins={coins} owned={ownedRewards} setCoins={setCoins}/>} 
   {page==='stats'&&<StatsPage t={t} weekly={weeklyData}/>} 
   {page==='achievements'&&<AchievementsPage t={t} unlocked={unlockedAchievements}/>} 
   {page==='settings'&&<SettingsPage t={t} lang={lang} setLang={setLang} dark={dark} setDark={setDark} reset={reset} online={online} cloud={!!supabase&&!!sessionUser}/>} 
  </main>
  <div className="mobileNav">{[['dashboard',LayoutDashboard,t.dashboard],['focus',AlarmClock,t.focus],['tasks',ListTodo,t.tasks],['rewards',Coins,t.rewards],['stats',BarChart3,t.stats]].map(([k,I,l])=><button key={k} className={page===k?'mobileNavItem active':'mobileNavItem'} onClick={()=>setPage(k)}><I size={19}/><span>{l}</span></button>)}</div>
  {focusOpen&&<FocusOverlay t={t} mm={String(Math.floor(seconds/60)).padStart(2,'0')} ss={String(seconds%60).padStart(2,'0')} running={running} setRunning={v=>{setRunning(v);if(v)setEndAt(Date.now()+seconds*1000)}} reset={resetTimer} finish={()=>completeFocus(false)} cancel={cancelFocus} selectedTask={selectedTask}/>} 
  {modal&&<TaskModal t={t} title={newTitle} setTitle={setNewTitle} subject={newSubject} setSubject={setNewSubject} save={addTask} close={()=>setModal(false)}/>} 
  {profileOpen&&<ProfileModal t={t} name={profileName} setName={updateProfile} user={sessionUser} auth={()=>{setProfileOpen(false);setAuthOpen(true)}} logout={async()=>{await supabase?.auth.signOut();setSessionUser(null);setProfileOpen(false)}} close={()=>setProfileOpen(false)}/>} 
  {authOpen&&<AuthModal t={t} close={()=>setAuthOpen(false)}/>} 
 </div>
}
function Dashboard({t,xp,level,coins,streak,tasks,totalMinutes,onFocus,toggleTask,setPage}){const done=tasks.filter(x=>x.done).length,prog=tasks.length?Math.round(done/tasks.length*100):0;return <div className="content"><div className="heroRow"><div><div className="eyebrow"><Sparkles size={14}/> {t.today}</div><h1>{t.welcome}</h1><p className="muted">Build momentum one focused session at a time.</p></div><button className="primaryBtn big" onClick={onFocus}><Play size={18} fill="currentColor"/>{t.start}<ArrowUpRight size={17}/></button></div><div className="statGrid"><Stat icon={<Flame/>} label={t.streak} value={streak}/><Stat icon={<Zap/>} label={t.level} value={level}/><Stat icon={<Coins/>} label={t.coins} value={coins.toLocaleString()}/><Stat icon={<Clock3/>} label={t.total} value={(totalMinutes/60).toFixed(1)} suffix={t.minutes}/></div><div className="grid2"><section className="panel progressPanel"><div className="panelHead"><div><h3>{t.today}</h3><p>{done}/{tasks.length} {t.completed}</p></div><Target size={20}/></div><div className="progressBig"><div className="ring"><div><strong>{prog}%</strong><span>{t.completed}</span></div></div><div className="progressCopy"><b>{done} / {tasks.length} tasks</b><span>{done*25} / 120 {t.minutes}</span><div className="bar"><i style={{width:`${prog}%`}}/></div><small>+{done*30} XP today</small></div></div></section><section className="panel levelPanel"><div className="panelHead"><div><h3>Level {level}</h3><p>Scholar in the making</p></div><Award size={20}/></div><div className="levelBadge"><GraduationCap size={38}/></div><div className="levelText"><div><b>{xp.toLocaleString()} XP</b><span> / {(level*500).toLocaleString()} XP</span></div><div className="bar"><i style={{width:`${(xp%500)/5||2}%`}}/></div></div></section></div><div className="gridMain"><section className="panel"><div className="panelHead"><div><h3>{t.missions}</h3><p>Complete them for bonus XP</p></div></div><div className="missionList"><div className="mission done"><span className="missionIcon">⏱️</span><div><b>Study for 90 minutes</b><small>+200 XP</small></div><Check size={20}/></div><div className="mission"><span className="missionIcon">📚</span><div><b>Finish 3 tasks</b><small>+150 XP</small></div></div><div className="mission"><span className="missionIcon">🔥</span><div><b>Keep your streak</b><small>+100 XP</small></div></div></div></section><section className="panel"><div className="panelHead"><div><h3>{t.tasks}</h3><p>Your next actions</p></div><button className="textBtn" onClick={()=>setPage('tasks')}>{t.all}<ChevronRight size={15}/></button></div><div className="taskRows">{tasks.slice(0,4).map(x=><div className="taskRow" key={x.id}><button className={x.done?'check done':'check'} onClick={()=>toggleTask(x.id)}>{x.done&&<Check size={14}/>}</button><div className="taskTitle"><b className={x.done?'strike':''}>{x.title}</b><span>{x.subject} · {x.minutes} min</span></div><span className={`priority ${x.priority}`}>{x.priority}</span><button className="ghostBtn" onClick={onFocus}><Play size={15}/></button></div>)}</div></section></div></div>}
function Stat({icon,label,value,suffix=''}){return <div className="statCard"><div className="statIcon">{icon}</div><span>{label}</span><strong>{value} <small>{suffix}</small></strong><em>Live</em></div>}
function FocusPage({t,tasks,selectedTask,setSelectedTask,duration,setDuration,onStart}){return <div className="content narrow"><div className="pageTitle"><div><div className="eyebrow"><AlarmClock size={14}/> FOCUS MODE</div><h1>{t.focusSession}</h1><p>{t.choose}, set your duration, and start.</p></div></div><div className="focusSetup panel"><div className="focusOrb"><div><Clock3 size={30}/><strong>{duration}</strong><span>{t.minutes}</span></div></div><div className="setupForm"><label>{t.choose}</label><select value={selectedTask} onChange={e=>setSelectedTask(e.target.value)}><option value="">No task</option>{tasks.filter(x=>!x.done).map(x=><option key={x.id} value={x.title}>{x.title}</option>)}</select><label>{t.duration}</label><div className="durationGrid">{[25,50,90].map(n=><button key={n} className={duration===n?'duration active':'duration'} onClick={()=>setDuration(n)}>{n}<small>{t.minutes}</small></button>)}</div><button className="primaryBtn wide" onClick={onStart}><Play size={18} fill="currentColor"/>{t.start}</button></div></div><div className="focusTips"><div><BrainIcon/><b>Deep work</b><span>One task, one protected time window.</span></div><div><ShieldCheck size={20}/><b>Reliable timer</b><span>The end time is timestamp-based.</span></div><div><Sparkles size={20}/><b>Earn rewards</b><span>Complete sessions for XP and coins.</span></div></div></div>}
function BrainIcon(){return <span style={{fontSize:20}}>🧠</span>}
function TasksPage({t,tasks,query,setQuery,filter,setFilter,toggleTask,openModal,onFocus}){return <div className="content"><div className="pageTitle split"><div><div className="eyebrow"><ListTodo size={14}/> TASK MANAGER</div><h1>{t.tasks}</h1><p>Turn your study plan into finishable actions.</p></div><button className="primaryBtn" onClick={openModal}><Plus size={18}/>{t.add}</button></div><div className="taskToolbar"><div className="search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t.search}/></div><div className="filters">{[['all',t.all],['active',t.active],['done',t.done]].map(([k,l])=><button key={k} className={filter===k?'filter active':'filter'} onClick={()=>setFilter(k)}>{l}</button>)}</div></div><section className="panel"><div className="taskRows large">{tasks.map(x=><div className="taskRow" key={x.id}><button className={x.done?'check done':'check'} onClick={()=>toggleTask(x.id)}>{x.done&&<Check size={14}/>}</button><div className="taskTitle"><b className={x.done?'strike':''}>{x.title}</b><span>{x.subject} · {x.minutes} min</span></div><span className={`priority ${x.priority}`}>{x.priority}</span><button className="ghostBtn" onClick={onFocus}><Play size={15}/></button></div>)}{!tasks.length&&<div className="empty"><ListTodo size={30}/><b>{t.noTasks}</b></div>}</div></section></div>}
function RewardsPage({t,coins,owned,setCoins}){return <div className="content"><div className="pageTitle"><div><div className="eyebrow"><Coins size={14}/> REWARD STORE</div><h1>{t.store}</h1></div><div className="coinPill"><Coins size={17}/>{coins.toLocaleString()}</div></div><div className="rewardGrid">{rewards.map(r=>{const has=owned.some(x=>x.name===r.name);return <div className="rewardCard" key={r.id}><div className="rewardIcon">{r.icon}</div><div><h3>{r.name}</h3><p>Unlock for your profile.</p></div><div className="rewardBottom"><b><Coins size={15}/>{r.cost}</b><button className="primaryBtn small" disabled={has||coins<r.cost} onClick={async()=>{const next=coins-r.cost;setCoins(next);if(supabase&&window.__ffUser){const u=window.__ffUser;await supabase.from('profiles').update({coins:next,updated_at:new Date().toISOString()}).eq('id',u.id);await supabase.from('rewards').insert({user_id:u.id,name:r.name,icon:r.icon,cost:r.cost,redeemed_count:1})}}}>{has?t.owned:t.buy}</button></div></div>})}</div></div>}
function StatsPage({t,weekly}){return <div className="content"><div className="pageTitle"><div><div className="eyebrow"><BarChart3 size={14}/> ANALYTICS</div><h1>{t.stats}</h1></div></div><div className="grid2"><section className="panel chartPanel"><div className="panelHead"><div><h3>{t.total}</h3><p>Hours of focused study</p></div></div><div className="chart"><ResponsiveContainer width="100%" height={270}><AreaChart data={weekly}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="day"/><YAxis/><Tooltip/><Area type="monotone" dataKey="focus" strokeWidth={3} fillOpacity={.12}/></AreaChart></ResponsiveContainer></div></section><section className="panel chartPanel"><div className="panelHead"><div><h3>Sessions</h3><p>Consistency across the week</p></div></div><div className="chart"><ResponsiveContainer width="100%" height={270}><BarChart data={weekly}><CartesianGrid strokeDasharray="3 3" vertical={false}/><XAxis dataKey="day"/><YAxis/><Tooltip/><Bar dataKey="focus" radius={[7,7,0,0]}/></BarChart></ResponsiveContainer></div></section></div></div>}
function AchievementsPage({t,unlocked}){return <div className="content"><div className="pageTitle"><div><div className="eyebrow"><Trophy size={14}/> ACHIEVEMENTS</div><h1>{t.achievements}</h1></div></div><div className="achievementGrid">{achievements.map(a=>{const isUnlocked=unlocked.some(x=>x.achievement_key===a[1]);return <div className={isUnlocked?'achievementCard unlocked':'achievementCard'} key={a[1]}><div className="achievementIcon">{a[0]}</div><div><h3>{a[1]}</h3><p>{a[2]}</p></div>{isUnlocked?<Check size={20}/>:<ShieldCheck size={20}/>}</div>})}</div></div>}
function SettingsPage({t,lang,setLang,dark,setDark,reset,online,cloud}){return <div className="content narrow"><div className="pageTitle"><div><div className="eyebrow"><Settings size={14}/> SETTINGS</div><h1>{t.settings}</h1></div></div><section className="panel settingsList"><SettingRow icon={<Globe2/>} title={t.language} desc="العربية / English"><button className="selectLike" onClick={()=>setLang(lang==='ar'?'en':'ar')}>{lang==='ar'?'العربية':'English'}<ChevronRight size={15}/></button></SettingRow><SettingRow icon={dark?<Moon/>:<Sun/>} title={t.theme} desc="Switch appearance"><div className="seg"><button className={!dark?'on':''} onClick={()=>setDark(false)}>{t.light}</button><button className={dark?'on':''} onClick={()=>setDark(true)}>{t.dark}</button></div></SettingRow><SettingRow icon={<Bell/>} title={t.notifications} desc="Session alerts"><div className="toggle on"><i/></div></SettingRow><SettingRow icon={<ShieldCheck/>} title={t.sync} desc={cloud?(online?'Supabase configured':'Offline — local changes are kept'):'Supabase not configured; local mode'}><span className="syncBadge">{cloud&&online?'Cloud':'Local'}</span></SettingRow><SettingRow icon={<RotateCcw/>} title={t.data} desc="Restore local app data"><button className="dangerBtn" onClick={reset}>{t.reset}</button></SettingRow></section></div>}
function SettingRow({icon,title,desc,children}){return <div className="settingRow"><div className="settingIcon">{icon}</div><div className="settingCopy"><b>{title}</b><span>{desc}</span></div>{children}</div>}
function TaskModal({t,title,setTitle,subject,setSubject,save,close}){return <div className="modalBackdrop"><div className="modal"><div className="modalHead"><div><h2>{t.newTask}</h2><p>Create a clear next action.</p></div><button className="iconBtn" onClick={close}><X/></button></div><label>{t.title}</label><input autoFocus value={title} onChange={e=>setTitle(e.target.value)}/><label>{t.subject}</label><input value={subject} onChange={e=>setSubject(e.target.value)}/><div className="modalActions"><button className="ghostBtn text" onClick={close}>{t.cancel}</button><button className="primaryBtn" onClick={save}><Plus size={17}/>{t.add}</button></div></div></div>}
function ProfileModal({t,name,setName,user,auth,logout,close}){const [draft,setDraft]=useState(name);return <div className="modalBackdrop"><div className="modal"><div className="modalHead"><div><h2>{t.profile}</h2><p>{user?user.email:'Local profile'}</p></div><button className="iconBtn" onClick={close}><X/></button></div><label>{t.name}</label><input value={draft} onChange={e=>setDraft(e.target.value)}/><div className="modalActions">{user?<button className="dangerBtn" onClick={logout}><LogOut size={16}/>{t.logout}</button>:<button className="ghostBtn text" onClick={auth}><LockKeyhole size={16}/>{t.login}</button>}<button className="primaryBtn" onClick={()=>{if(draft.trim())setName(draft.trim());close()}}><Check size={17}/>{t.save}</button></div></div></div>}
function AuthModal({t,close}){const [mode,setMode]=useState('login'),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[name,setName]=useState(''),[msg,setMsg]=useState('');const submit=async()=>{if(!supabase){setMsg('Cloud account is not configured. Local mode is active.');return}const res=mode==='login'?await supabase.auth.signInWithPassword({email,password}):await supabase.auth.signUp({email,password,options:{data:{display_name:name||'Student'},emailRedirectTo:window.location.origin}});setMsg(res.error?.message||(mode==='login'?'Signed in.':'Check your email to confirm your account.'));if(!res.error&&mode==='login')close()};return <div className="modalBackdrop"><div className="modal"><div className="modalHead"><div><h2>{mode==='login'?t.login:t.signup}</h2><p>{supabase?'Secure Supabase authentication':'Configure Supabase to enable cloud accounts.'}</p></div><button className="iconBtn" onClick={close}><X/></button></div>{mode==='signup'&&<><label>{t.name}</label><input value={name} onChange={e=>setName(e.target.value)}/></>}<label>{t.email}</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)}/><label>{t.password}</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)}/>{msg&&<p className="muted">{msg}</p>}<div className="modalActions"><button className="ghostBtn text" onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?t.signup:t.login}</button><button className="primaryBtn" onClick={submit}>{mode==='login'?t.login:t.signup}</button></div></div></div>}
function FocusOverlay({t,mm,ss,running,setRunning,reset,finish,cancel,selectedTask}){return <div className="focusOverlay"><div className="focusTop"><div className="brand"><div className="brandMark"><Zap size={21}/></div><div><b>FocusForge</b><span>Deep focus mode</span></div></div><button className="iconBtn lightBtn" onClick={cancel}><X/></button></div><div className="focusCenter"><div className="focusLabel"><span className="pulse"/>{selectedTask||'Focus session'}</div><div className="timer">{mm}<span>:</span>{ss}</div><p>Stay with one task. Everything else can wait.</p><div className="timerActions"><button className="circleBtn" onClick={reset}><RotateCcw/></button><button className="playBig" onClick={()=>setRunning(!running)}>{running?'Ⅱ':<Play fill="currentColor"/>}</button><button className="finishBtn" onClick={finish}><Check/> {t.finish}</button></div></div><div className="focusBottom"><span>⚡ +120 XP</span><span>🪙 +25 coins</span><span>🔕 Focus mode</span></div></div>}

if('serviceWorker' in navigator) addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
createRoot(document.getElementById('root')).render(<App/>);
